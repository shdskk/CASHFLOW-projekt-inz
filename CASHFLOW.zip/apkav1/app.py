from __future__ import annotations

import os

from flask import Flask

from database import init_db
from routes.web import bp as web_bp, inject_csrf, csrf_bootstrap


def create_app() -> Flask:
    app = Flask(__name__)

  
    app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-key-change-me")

    
    app.config.update(
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
    )

    init_db()

    
    app.context_processor(inject_csrf)
    app.before_request(csrf_bootstrap)

    
    app.register_blueprint(web_bp)
    return app


if __name__ == "__main__":
    create_app().run(debug=True)
