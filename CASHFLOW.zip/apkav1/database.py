import os
import sqlite3
from pathlib import Path

def _default_db_path() -> Path:
    """Return a stable per-user DB location (so copying the project folder doesn't create a new empty DB).

    Priority:
      1) env BUDGET_APP_DB (explicit override)
      2) OS-specific user data dir
    """
    override = os.environ.get("BUDGET_APP_DB")
    if override:
        return Path(override).expanduser().resolve()

    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or (Path.home() / "AppData" / "Local"))
        data_dir = base / "BudgetApp"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))
        data_dir = base / "budget_app"

    data_dir.mkdir(parents=True, exist_ok=True)
    return (data_dir / "budget.db").resolve()

DB_PATH = _default_db_path()

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    # Enforce FK constraints
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def _has_column(conn: sqlite3.Connection, table: str, column: str) -> bool:
    cols = conn.execute(f"PRAGMA table_info({table})").fetchall()
    return any(r[1] == column for r in cols)  # r[1] = name

def init_db():
    conn = get_db_connection()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password BLOB NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            amount REAL NOT NULL CHECK (amount >= 0),
            type TEXT NOT NULL CHECK (type IN ('income','expense')),
            category TEXT NOT NULL,
            description TEXT,
            date TEXT NOT NULL,
            user_id INTEGER NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

    
    if not _has_column(conn, "transactions", "recurring_id"):
        conn.execute("ALTER TABLE transactions ADD COLUMN recurring_id INTEGER")

    
    conn.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS idx_transactions_recurring_unique
        ON transactions(user_id, recurring_id, date)
        WHERE recurring_id IS NOT NULL
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS limits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            month TEXT NOT NULL,            -- format: YYYY-MM
            category TEXT NOT NULL,
            limit_amount REAL NOT NULL CHECK (limit_amount >= 0),
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            UNIQUE(user_id, month, category),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

   
    conn.execute("""
        CREATE TABLE IF NOT EXISTS goals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            target_amount REAL NOT NULL CHECK (target_amount >= 0),
            current_amount REAL NOT NULL DEFAULT 0 CHECK (current_amount >= 0),
            start_date TEXT NOT NULL,      -- YYYY-MM-DD
            target_date TEXT,              -- optional YYYY-MM-DD
            notes TEXT,
            is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS goal_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            goal_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            amount REAL NOT NULL,          -- positive = deposit, negative = withdrawal
            entry_date TEXT NOT NULL,      -- YYYY-MM-DD
            note TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY(goal_id) REFERENCES goals(id) ON DELETE CASCADE,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)


    
    
    if _has_column(conn, "recurring", "interval"):
        conn.execute("PRAGMA foreign_keys = OFF;")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS recurring_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount REAL NOT NULL CHECK (amount >= 0),
                type TEXT NOT NULL CHECK (type IN ('income','expense')),
                category TEXT NOT NULL,
                description TEXT,
                start_date TEXT NOT NULL,  -- YYYY-MM-DD
                frequency TEXT NOT NULL CHECK (frequency IN ('daily','weekly','monthly')),
                end_date TEXT,             -- optional YYYY-MM-DD
                last_generated_date TEXT,  -- YYYY-MM-DD (last inserted occurrence)
                is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)
       
        conn.execute("""
            INSERT INTO recurring_new (
                id, user_id, amount, type, category, description,
                start_date, frequency, end_date, last_generated_date, is_active, created_at
            )
            SELECT
                id, user_id, amount, type, category, description,
                start_date, frequency, end_date, last_generated_date, is_active, created_at
            FROM recurring
        """)
        conn.execute("DROP TABLE recurring")
        conn.execute("ALTER TABLE recurring_new RENAME TO recurring")
        conn.execute("PRAGMA foreign_keys = ON;")

    conn.execute("""
        CREATE TABLE IF NOT EXISTS recurring (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            amount REAL NOT NULL CHECK (amount >= 0),
            type TEXT NOT NULL CHECK (type IN ('income','expense')),
            category TEXT NOT NULL,
            description TEXT,
            start_date TEXT NOT NULL,  -- YYYY-MM-DD
            frequency TEXT NOT NULL CHECK (frequency IN ('daily','weekly','monthly')),
            end_date TEXT,             -- optional YYYY-MM-DD
            last_generated_date TEXT,  -- YYYY-MM-DD (last inserted occurrence)
            is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

    conn.commit()
    conn.close()
