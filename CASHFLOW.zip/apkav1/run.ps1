
$ErrorActionPreference = "Stop"


if (-Not (Test-Path ".venv")) {
    python -m venv .venv
}


. .\.venv\Scripts\Activate.ps1


pip install -r requirements.txt

$env:SECRET_KEY = "dev-secret-key"


python app.py
