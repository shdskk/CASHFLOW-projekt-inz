# Aplikacja budżetowa (Flask + SQLite)

Aplikacja webowa do zarządzania budżetem domowym: przychody, wydatki, filtrowanie, wykresy, eksport CSV oraz limity wydatków.

## Funkcje
- Rejestracja i logowanie użytkowników (hasła hashowane bcrypt)
- Dodawanie, edycja i usuwanie transakcji
- Filtrowanie po miesiącu, opisie i kategorii
- Podsumowanie (przychody / wydatki / saldo)
- Wykres dzienny (Chart.js)
- Eksport danych do CSV
- Limity wydatków na kategorie (z ostrzeżeniami w panelu)

## Wymagania
- Python 3.10+ (polecane 3.11)
- pip

## Instalacja i uruchomienie
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/Mac:
# source .venv/bin/activate

pip install -r requirements.txt

# (opcjonalnie) klucz sesji:
# Windows (PowerShell):  $env:SECRET_KEY="twoj-super-klucz"
# Linux/Mac:             export SECRET_KEY="twoj-super-klucz"

python app.py
```

Skróty uruchomieniowe:
- Windows (PowerShell): `./run.ps1`
- Linux/Mac: `./run.sh`

Aplikacja uruchomi się pod adresem: http://127.0.0.1:5000

## Baza danych
- SQLite: plik `budget.db` tworzy się automatycznie przy pierwszym uruchomieniu.
- Tabele: `users`, `transactions`, `limits`.

## Bezpieczeństwo (skrót)
- Hasła przechowywane jako hash bcrypt
- Operacje usuwania realizowane metodą POST
- Prosta ochrona CSRF (token w sesji) dla wszystkich formularzy POST
- Klucz sesji może być dostarczony przez zmienną środowiskową `SECRET_KEY`


## Cykliczne przychody i wydatki

Pod przyciskiem **Dodaj transakcję** wybierz opcję **Cykliczne**, aby dodać reguły (np. czynsz co miesiąc). Aplikacja generuje transakcje „z reguł” automatycznie przy wejściu do panelu (bez crona).


## Baza danych (bezobsługowo)
Aplikacja zapisuje bazę SQLite w **stałej lokalizacji użytkownika**, dzięki czemu przenoszenie/kopiowanie folderu projektu
nie tworzy nowej pustej bazy.

- Windows: `%LOCALAPPDATA%\BudgetApp\budget.db` (lub `%APPDATA%\BudgetApp\budget.db`)
- Linux: `~/.local/share/budget_app/budget.db` (lub `$XDG_DATA_HOME/budget_app/budget.db`)
- Mac: również `~/.local/share/budget_app/budget.db` (chyba że ustawisz `XDG_DATA_HOME`)

W razie potrzeby możesz wymusić ścieżkę:
- `BUDGET_APP_DB=/sciezka/do/budget.db`

Aby „wyzerować” aplikację, usuń plik `budget.db` z powyższej lokalizacji.
