
set -euo pipefail



if [[ ! -d .venv ]]; then
  python3 -m venv .venv
fi


source .venv/bin/activate

pip install -r requirements.txt


export SECRET_KEY="${SECRET_KEY:-dev-secret-key}"

python app.py
