from __future__ import annotations

import sqlite3


def upsert_limit(conn: sqlite3.Connection, user_id: int, month: str, category: str, limit_amount: float) -> None:
    conn.execute(
        """
        INSERT INTO limits (user_id, month, category, limit_amount)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(user_id, month, category) DO UPDATE SET
            limit_amount = excluded.limit_amount
        """,
        (user_id, month, category, float(limit_amount)),
    )


def list_limits(conn: sqlite3.Connection, user_id: int):
    return conn.execute(
        """
        SELECT id, month, category, limit_amount
        FROM limits
        WHERE user_id = ?
        ORDER BY month DESC, category ASC
        """,
        (user_id,),
    ).fetchall()


def delete_limit(conn: sqlite3.Connection, user_id: int, limit_id: int) -> None:
    conn.execute("DELETE FROM limits WHERE id = ? AND user_id = ?", (int(limit_id), user_id))


def list_limits_for_month(conn: sqlite3.Connection, user_id: int, month: str):
    return conn.execute(
        """
        SELECT category, limit_amount
        FROM limits
        WHERE user_id = ? AND month = ?
        """,
        (user_id, month),
    ).fetchall()


def spent_by_category_for_month(conn: sqlite3.Connection, user_id: int, month_prefix: str):
    return conn.execute(
        """
        SELECT category, COALESCE(SUM(amount),0) AS total
        FROM transactions
        WHERE user_id = ? AND type = 'expense' AND date LIKE ?
        GROUP BY category
        """,
        (user_id, month_prefix + "%"),
    ).fetchall()


def get_limit_amount(conn: sqlite3.Connection, user_id: int, month: str, category: str):
    return conn.execute(
        """
        SELECT limit_amount
        FROM limits
        WHERE user_id = ? AND month = ? AND category = ?
        """,
        (user_id, month, category),
    ).fetchone()


def total_expenses_for_category_month(conn: sqlite3.Connection, user_id: int, month: str, category: str) -> float:
    row = conn.execute(
        """
        SELECT COALESCE(SUM(amount),0)
        FROM transactions
        WHERE user_id = ?
          AND type = 'expense'
          AND category = ?
          AND date LIKE ?
        """,
        (user_id, category, month + "%"),
    ).fetchone()
    return float(row[0] or 0.0)
