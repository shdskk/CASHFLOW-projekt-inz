from __future__ import annotations

from typing import Optional, Sequence, Tuple
import sqlite3


def list_month_transactions(
    conn: sqlite3.Connection,
    user_id: int,
    month_prefix: str,
    search: str = "",
    category_filter: str = "",
):
    query = "SELECT * FROM transactions WHERE user_id = ? AND date LIKE ?"
    params = [user_id, month_prefix + "%"]

    if search:
        query += " AND description LIKE ?"
        params.append(f"%{search}%")
    if category_filter:
        query += " AND category LIKE ?"
        params.append(f"%{category_filter}%")

    query += " ORDER BY date DESC"
    return conn.execute(query, tuple(params)).fetchall()


def sum_month_by_type(conn: sqlite3.Connection, user_id: int, month_prefix: str, type_: str) -> float:
    row = conn.execute(
        """
        SELECT COALESCE(SUM(amount),0) FROM transactions
        WHERE user_id = ? AND type = ? AND date LIKE ?
        """,
        (user_id, type_, month_prefix + "%"),
    ).fetchone()
    return float(row[0] or 0)


def list_month_amounts_for_chart(conn: sqlite3.Connection, user_id: int, month_prefix: str):
    return conn.execute(
        """
        SELECT date, amount, type FROM transactions
        WHERE user_id = ? AND date LIKE ?
        """,
        (user_id, month_prefix + "%"),
    ).fetchall()


def get_transaction(conn: sqlite3.Connection, user_id: int, transaction_id: int):
    return conn.execute(
        "SELECT * FROM transactions WHERE id = ? AND user_id = ?",
        (transaction_id, user_id),
    ).fetchone()


def create_transaction(
    conn: sqlite3.Connection,
    user_id: int,
    amount: float,
    type_: str,
    category: str,
    description: str,
    date_str: str,
) -> None:
    conn.execute(
        """
        INSERT INTO transactions (amount, type, category, description, date, user_id)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (amount, type_, category, description, date_str, user_id),
    )


def update_transaction(
    conn: sqlite3.Connection,
    user_id: int,
    transaction_id: int,
    amount: float,
    type_: str,
    category: str,
    description: str,
    date_str: str,
) -> None:
    conn.execute(
        """
        UPDATE transactions
        SET amount = ?, type = ?, category = ?, description = ?, date = ?
        WHERE id = ? AND user_id = ?
        """,
        (amount, type_, category, description, date_str, transaction_id, user_id),
    )


def delete_transaction(conn: sqlite3.Connection, user_id: int, transaction_id: int) -> None:
    conn.execute(
        "DELETE FROM transactions WHERE id = ? AND user_id = ?",
        (transaction_id, user_id),
    )
