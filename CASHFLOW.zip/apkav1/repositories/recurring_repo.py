from __future__ import annotations

import sqlite3
from typing import Optional


def list_active_rules(conn: sqlite3.Connection, user_id: int):
    return conn.execute(
        """
        SELECT *
        FROM recurring
        WHERE user_id = ? AND is_active = 1
        """,
        (user_id,),
    ).fetchall()


def insert_generated_transaction(
    conn: sqlite3.Connection,
    user_id: int,
    recurring_id: int,
    amount: float,
    type_: str,
    category: str,
    description: str,
    date_str: str,
) -> None:
    conn.execute(
        """
        INSERT OR IGNORE INTO transactions (amount, type, category, description, date, user_id, recurring_id)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (float(amount), type_, category, (description or "").strip(), date_str, user_id, int(recurring_id)),
    )


def update_last_generated(conn: sqlite3.Connection, user_id: int, recurring_id: int, date_str: str) -> None:
    conn.execute(
        "UPDATE recurring SET last_generated_date = ? WHERE id = ? AND user_id = ?",
        (date_str, int(recurring_id), user_id),
    )


def create_rule(
    conn: sqlite3.Connection,
    user_id: int,
    amount: float,
    type_: str,
    category: str,
    description: str,
    start_date: str,
    frequency: str,
    end_date: Optional[str],
) -> None:
    conn.execute(
        """
        INSERT INTO recurring (user_id, amount, type, category, description, start_date, frequency, end_date)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (user_id, float(amount), type_, category, description, start_date, frequency, end_date),
    )


def list_rules(conn: sqlite3.Connection, user_id: int):
    return conn.execute(
        """
        SELECT *
        FROM recurring
        WHERE user_id = ?
        ORDER BY created_at DESC
        """,
        (user_id,),
    ).fetchall()


def get_rule_active_flag(conn: sqlite3.Connection, user_id: int, recurring_id: int):
    return conn.execute(
        "SELECT id, is_active FROM recurring WHERE id = ? AND user_id = ?",
        (int(recurring_id), user_id),
    ).fetchone()


def set_rule_active_flag(conn: sqlite3.Connection, user_id: int, recurring_id: int, is_active: int) -> None:
    conn.execute(
        "UPDATE recurring SET is_active = ? WHERE id = ? AND user_id = ?",
        (int(is_active), int(recurring_id), user_id),
    )


def delete_generated_transactions(conn: sqlite3.Connection, user_id: int, recurring_id: int) -> None:
    conn.execute(
        "DELETE FROM transactions WHERE user_id = ? AND recurring_id = ?",
        (user_id, int(recurring_id)),
    )


def delete_rule(conn: sqlite3.Connection, user_id: int, recurring_id: int) -> None:
    conn.execute(
        "DELETE FROM recurring WHERE id = ? AND user_id = ?",
        (int(recurring_id), user_id),
    )
