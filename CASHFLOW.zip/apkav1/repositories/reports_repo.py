from __future__ import annotations

import sqlite3


def list_transactions_for_report(
    conn: sqlite3.Connection,
    user_id: int,
    month_prefix: str,
    search: str = "",
    category_filter: str = "",
):
    query = """
        SELECT date, category, description, amount, type
        FROM transactions
        WHERE user_id = ? AND date LIKE ?
    """
    params = [user_id, month_prefix + "%"]

    if search:
        query += " AND description LIKE ?"
        params.append(f"%{search}%")
    if category_filter:
        query += " AND category LIKE ?"
        params.append(f"%{category_filter}%")

    query += " ORDER BY date ASC"
    return conn.execute(query, tuple(params)).fetchall()


def sum_month_by_type(conn: sqlite3.Connection, user_id: int, month_prefix: str, type_: str) -> float:
    row = conn.execute(
        """
        SELECT COALESCE(SUM(amount),0) FROM transactions
        WHERE user_id = ? AND type = ? AND date LIKE ?
        """,
        (user_id, type_, month_prefix + "%"),
    ).fetchone()
    return float(row[0] or 0.0)
