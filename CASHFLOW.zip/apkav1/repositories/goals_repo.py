from __future__ import annotations

import sqlite3
from typing import Optional


def create_goal(
    conn: sqlite3.Connection,
    user_id: int,
    name: str,
    target_amount: float,
    start_date: str,
    target_date: Optional[str],
    notes: Optional[str],
) -> None:
    conn.execute(
        """
        INSERT INTO goals (user_id, name, target_amount, current_amount, start_date, target_date, notes)
        VALUES (?, ?, ?, 0, ?, ?, ?)
        """,
        (user_id, name, float(target_amount), start_date, target_date, notes),
    )


def list_goals(conn: sqlite3.Connection, user_id: int):
    return conn.execute(
        """
        SELECT *
        FROM goals
        WHERE user_id = ?
        ORDER BY is_active DESC, created_at DESC
        """,
        (user_id,),
    ).fetchall()


def list_goal_entries(conn: sqlite3.Connection, user_id: int, goal_id: int, limit: int = 5):
    return conn.execute(
        """
        SELECT entry_date, amount, note
        FROM goal_entries
        WHERE user_id = ? AND goal_id = ?
        ORDER BY entry_date DESC, id DESC
        LIMIT ?
        """,
        (user_id, goal_id, int(limit)),
    ).fetchall()


def get_goal_for_entry(conn: sqlite3.Connection, user_id: int, goal_id: int):
    return conn.execute(
        "SELECT id, current_amount, is_active FROM goals WHERE id = ? AND user_id = ?",
        (goal_id, user_id),
    ).fetchone()


def add_goal_entry_and_update_current(
    conn: sqlite3.Connection,
    user_id: int,
    goal_id: int,
    signed_amount: float,
    entry_date: str,
    note: Optional[str],
    new_current_amount: float,
) -> None:
    conn.execute(
        """
        INSERT INTO goal_entries (goal_id, user_id, amount, entry_date, note)
        VALUES (?, ?, ?, ?, ?)
        """,
        (goal_id, user_id, float(signed_amount), entry_date, note),
    )
    conn.execute(
        "UPDATE goals SET current_amount = ? WHERE id = ? AND user_id = ?",
        (float(new_current_amount), goal_id, user_id),
    )


def get_goal_active_flag(conn: sqlite3.Connection, user_id: int, goal_id: int):
    return conn.execute(
        "SELECT is_active FROM goals WHERE id = ? AND user_id = ?",
        (goal_id, user_id),
    ).fetchone()


def set_goal_active_flag(conn: sqlite3.Connection, user_id: int, goal_id: int, is_active: int) -> None:
    conn.execute(
        "UPDATE goals SET is_active = ? WHERE id = ? AND user_id = ?",
        (int(is_active), goal_id, user_id),
    )


def delete_goal(conn: sqlite3.Connection, user_id: int, goal_id: int) -> None:
    conn.execute("DELETE FROM goals WHERE id = ? AND user_id = ?", (goal_id, user_id))
