from __future__ import annotations

from collections import defaultdict
from typing import Dict, List, Tuple

def category_breakdown(rows) -> Tuple[List[Tuple[str, float]], List[Tuple[str, float]]]:
    """Return (income_categories, expense_categories) sorted desc by amount."""
    income_by_cat = defaultdict(float)
    expense_by_cat = defaultdict(float)

    for r in rows:
        cat = (r["category"] or "").strip() or "Inne"
        if r["type"] == "income":
            income_by_cat[cat] += float(r["amount"])
        else:
            expense_by_cat[cat] += float(r["amount"])

    income_categories = sorted(income_by_cat.items(), key=lambda x: x[1], reverse=True)
    expense_categories = sorted(expense_by_cat.items(), key=lambda x: x[1], reverse=True)
    return income_categories, expense_categories
