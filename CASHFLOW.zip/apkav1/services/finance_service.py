from __future__ import annotations

import sqlite3


def compute_frozen_total(conn: sqlite3.Connection, user_id: int) -> float:
    """Sum of money allocated to active savings goals."""
    row = conn.execute(
        "SELECT COALESCE(SUM(current_amount), 0) FROM goals WHERE user_id = ? AND is_active = 1",
        (user_id,),
    ).fetchone()
    return float(row[0] or 0.0)
