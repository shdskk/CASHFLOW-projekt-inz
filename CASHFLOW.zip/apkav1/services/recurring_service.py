from __future__ import annotations

import calendar
from datetime import date, datetime, timedelta
from typing import Optional

import sqlite3

from repositories.recurring_repo import (
    list_active_rules,
    insert_generated_transaction,
    update_last_generated,
)

ALLOWED_FREQUENCIES = ("daily", "weekly", "monthly")


def parse_iso_date(s: str) -> Optional[date]:
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except Exception:
        return None


def to_iso(d: date) -> str:
    return d.strftime("%Y-%m-%d")


def add_months(d: date, months: int) -> date:
    # Keep day-of-month when possible, otherwise clamp to last day.
    y = d.year + (d.month - 1 + months) // 12
    m = (d.month - 1 + months) % 12 + 1
    last_day = calendar.monthrange(y, m)[1]
    day = min(d.day, last_day)
    return date(y, m, day)


def advance(d: date, frequency: str) -> date:
    if frequency == "daily":
        return d + timedelta(days=1)
    if frequency == "weekly":
        return d + timedelta(weeks=1)
    if frequency == "monthly":
        return add_months(d, 1)
    raise ValueError("Invalid frequency")


def ensure_recurring_generated(conn: sqlite3.Connection, user_id: int) -> None:
    """Materialize recurring rules into concrete transactions up to today.

    Runs on-demand (e.g. when opening the dashboard), so no scheduler is required.
    """
    today = date.today()

    rules = list_active_rules(conn, user_id)

    for r in rules:
        start = parse_iso_date(r["start_date"])
        if not start:
            continue

        end = parse_iso_date(r["end_date"]) if (r["end_date"] or "").strip() else None
        if end and end < start:
            continue

        freq = r["frequency"]
        last_gen = parse_iso_date(r["last_generated_date"]) if (r["last_generated_date"] or "").strip() else None
        next_date = start if last_gen is None else advance(last_gen, freq)

        while next_date <= today and (end is None or next_date <= end):
            insert_generated_transaction(
                conn=conn,
                user_id=user_id,
                recurring_id=int(r["id"]),
                amount=float(r["amount"]),
                type_=r["type"],
                category=r["category"],
                description=(r["description"] or "").strip(),
                date_str=to_iso(next_date),
            )
            update_last_generated(conn, user_id, int(r["id"]), to_iso(next_date))
            next_date = advance(next_date, freq)


def get_next_occurrence(row) -> Optional[str]:
    """Used only for UI (display next scheduled date)."""
    start = parse_iso_date(row["start_date"])
    if not start:
        return None
    freq = row["frequency"]
    last_gen = parse_iso_date(row["last_generated_date"]) if (row["last_generated_date"] or "").strip() else None
    next_date = start if last_gen is None else advance(last_gen, freq)
    return to_iso(next_date)
