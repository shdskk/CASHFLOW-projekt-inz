from __future__ import annotations

import sqlite3
from typing import List, Optional, Tuple

from repositories.limits_repo import (
    list_limits_for_month,
    spent_by_category_for_month,
    get_limit_amount,
    total_expenses_for_category_month,
)


def get_limit_warnings(conn: sqlite3.Connection, user_id: int, selected_month: str) -> List[str]:
    """Return warnings like 'cat: wydano X / limit Y' for the given month."""
    limits = list_limits_for_month(conn, user_id, selected_month)
    if not limits:
        return []

    spent = spent_by_category_for_month(conn, user_id, selected_month)
    spent_map = {r["category"]: float(r["total"] or 0) for r in spent}

    warnings: List[str] = []
    for l in limits:
        cat = l["category"]
        lim = float(l["limit_amount"])
        total = spent_map.get(cat, 0.0)
        if total > lim and lim > 0:
            warnings.append(f"{cat}: wydano {total:.2f} zł / limit {lim:.2f} zł")
    return warnings


def check_limit_exceeded(conn: sqlite3.Connection, user_id: int, month: str, category: str) -> Tuple[bool, float, Optional[float]]:
    """Return (exceeded, total, limit) for an expense category in YYYY-MM.

    If no limit is set, returns (False, total, None).
    """
    lim_row = get_limit_amount(conn, user_id, month, category)
    total = total_expenses_for_category_month(conn, user_id, month, category)

    if not lim_row:
        return False, float(total), None

    lim = float(lim_row["limit_amount"])
    return float(total) > lim, float(total), lim
