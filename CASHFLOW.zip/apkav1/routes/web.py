from __future__ import annotations

import os
import re
import csv
import io
import secrets
from datetime import datetime, date, timedelta
import calendar
from collections import defaultdict
from typing import Optional, Tuple, List

import bcrypt
from flask import Blueprint, render_template, request, redirect, session, flash, url_for, send_file, abort

from database import get_db_connection, init_db
from repositories.transactions_repo import (

    list_month_transactions,
    sum_month_by_type,
    list_month_amounts_for_chart,
    get_transaction as repo_get_transaction,
    create_transaction as repo_create_transaction,
    update_transaction as repo_update_transaction,
    delete_transaction as repo_delete_transaction,
)

from repositories.goals_repo import (
    create_goal as repo_create_goal,
    list_goals as repo_list_goals,
    list_goal_entries as repo_list_goal_entries,
    get_goal_for_entry as repo_get_goal_for_entry,
    add_goal_entry_and_update_current as repo_add_goal_entry_and_update_current,
    get_goal_active_flag as repo_get_goal_active_flag,
    set_goal_active_flag as repo_set_goal_active_flag,
    delete_goal as repo_delete_goal,
)
from services.finance_service import compute_frozen_total
from repositories.recurring_repo import (
    create_rule as repo_create_recurring_rule,
    list_rules as repo_list_recurring_rules,
    get_rule_active_flag as repo_get_recurring_active_flag,
    set_rule_active_flag as repo_set_recurring_active_flag,
    delete_generated_transactions as repo_delete_generated_transactions,
    delete_rule as repo_delete_recurring_rule,
)
from services.recurring_service import (
    ensure_recurring_generated,
    get_next_occurrence,
    parse_iso_date as recurring_parse_iso_date,
    ALLOWED_FREQUENCIES,
)
from repositories.limits_repo import (
    upsert_limit as repo_upsert_limit,
    list_limits as repo_list_limits,
    delete_limit as repo_delete_limit,
)
from services.limits_service import (
    get_limit_warnings,
    check_limit_exceeded,
)
from repositories.reports_repo import (
    list_transactions_for_report as repo_list_transactions_for_report,
    sum_month_by_type as repo_report_sum_month_by_type,
)
from services.report_service import category_breakdown



USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")


bp = Blueprint('web', __name__)




def _get_csrf_token() -> str:
   
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["csrf_token"] = token
    return token


def csrf_bootstrap():
    _get_csrf_token()


def _require_csrf() -> None:
    
    sent = (request.form.get("csrf_token") or "").strip()
    token = session.get("csrf_token")
    if not token or not sent or not secrets.compare_digest(sent, token):
        abort(400)


def inject_csrf():
    return {"csrf_token": _get_csrf_token}

def require_login():
   
    uid = session.get("user_id")
    if not uid:
        return False

    try:
        conn = get_db_connection()
        row = conn.execute("SELECT id FROM users WHERE id = ?", (int(uid),)).fetchone()
        conn.close()
        if not row:
            
            session.clear()
            return False
        return True
    except Exception:
        
        session.clear()
        return False

def parse_amount(value: str) -> Optional[float]:
    try:
        amount = float(value)
        if amount < 0:
            return None
        return round(amount, 2)
    except Exception:
        return None

def parse_date(value: str) -> Optional[str]:
    try:
        
        datetime.strptime(value, "%Y-%m-%d")
        return value
    except Exception:
        return None

def current_month() -> str:
    return datetime.today().strftime("%Y-%m")



@bp.route("/")
def index():
    if not require_login():
        return redirect(url_for("web.login"))

    user_id = int(session["user_id"])
    selected_month = (request.args.get("month") or current_month()).strip()
    search = (request.args.get("search") or "").strip()
    category_filter = (request.args.get("category") or "").strip()

    conn = get_db_connection()
    ensure_recurring_generated(conn, user_id)


    transactions = list_month_transactions(conn, user_id, selected_month, search=search, category_filter=category_filter)

    income_sum = sum_month_by_type(conn, user_id, selected_month, 'income')


    expense_sum = sum_month_by_type(conn, user_id, selected_month, 'expense')


 
    saldo_raw = float(income_sum) - float(expense_sum)
    
    frozen_total = compute_frozen_total(conn, user_id)

   
    saldo = float(saldo_raw) - float(frozen_total)
    data = list_month_amounts_for_chart(conn, user_id, selected_month)

    daily_data = defaultdict(lambda: {"income": 0.0, "expense": 0.0})
    for row in data:
        day = row["date"][-2:]
        daily_data[day][row["type"]] += float(row["amount"])

    labels = sorted(daily_data.keys())
    income_data = [round(daily_data[d]["income"], 2) for d in labels]
    expense_data = [round(daily_data[d]["expense"], 2) for d in labels]

    limit_warnings = get_limit_warnings(conn, user_id, selected_month)

    conn.close()

    return render_template(
        "index.html",
        title="Panel budżetu",
        transactions=transactions,
        income_sum=float(income_sum),
        expense_sum=float(expense_sum),
        saldo=float(saldo),
        saldo_raw=float(saldo_raw),
        frozen_total=float(frozen_total),
        chart_labels=labels,
        chart_income=income_data,
        chart_expense=expense_data,
        selected_month=selected_month,
        search=search,
        category_filter=category_filter,
        limit_warnings=limit_warnings,
    )

@bp.route("/add", methods=["GET", "POST"])
def add():
    if not require_login():
        return redirect(url_for("web.login"))

    mode = (request.args.get("mode") or "").strip().lower()

    
    if request.method == "GET" and mode not in ("single", "recurring"):
        return render_template("add_choice.html", title="Dodaj")

    
    if request.method == "GET" and mode == "recurring":
        return redirect(url_for("web.recurring") + "#new")

    if request.method == "POST":
        _require_csrf()
        amount = parse_amount(request.form.get("amount", ""))
        type_ = (request.form.get("type") or "").strip()
        category = (request.form.get("category") or "").strip()
        description = (request.form.get("description") or "").strip()
        date = parse_date(request.form.get("date", ""))

        if amount is None:
            flash("Nieprawidłowa kwota.", "danger")
            return redirect(url_for("web.add", mode="single"))
        if type_ not in ("income", "expense"):
            flash("Nieprawidłowy typ transakcji.", "danger")
            return redirect(url_for("web.add", mode="single"))
        if not category:
            flash("Kategoria jest wymagana.", "danger")
            return redirect(url_for("web.add", mode="single"))
        if date is None:
            flash("Nieprawidłowa data.", "danger")
            return redirect(url_for("web.add", mode="single"))

        user_id = int(session["user_id"])

        conn = get_db_connection()
        repo_create_transaction(conn, user_id, amount, type_, category, description, date)
       
        if type_ == "expense":
            month = date[:7]
            exceeded, total, lim = check_limit_exceeded(conn, user_id, month, category)
            if exceeded and lim is not None:
                flash(
                    f"⚠️ Przekroczono limit dla kategorii '{category}' w {month}: "
                    f"{total:.2f} zł / {lim:.2f} zł.",
                    "warning",
                )
        conn.commit()
        conn.close()

        flash("Dodano transakcję.", "success")
        return redirect(url_for("web.index"))

   
    return render_template(
        "add.html",
        title="Dodaj transakcję",
        today=datetime.today().strftime("%Y-%m-%d"),
    )


@bp.route("/edit/<int:transaction_id>", methods=["GET", "POST"])
def edit(transaction_id: int):
    if not require_login():
        return redirect(url_for("web.login"))

    user_id = int(session["user_id"])
    conn = get_db_connection()
    transaction = repo_get_transaction(conn, user_id, transaction_id)

    if not transaction:
        conn.close()
        flash("Nie znaleziono transakcji.", "warning")
        return redirect(url_for("web.index"))

    if request.method == "POST":
        _require_csrf()
        amount = parse_amount(request.form.get("amount", ""))
        type_ = (request.form.get("type") or "").strip()
        category = (request.form.get("category") or "").strip()
        description = (request.form.get("description") or "").strip()
        date = parse_date(request.form.get("date", ""))

        if amount is None or type_ not in ("income", "expense") or not category or date is None:
            conn.close()
            flash("Nieprawidłowe dane formularza.", "danger")
            return redirect(url_for("web.edit", transaction_id=transaction_id))

        conn.execute(
            """
            UPDATE transactions
            SET amount = ?, type = ?, category = ?, description = ?, date = ?
            WHERE id = ? AND user_id = ?
            """,
            (amount, type_, category, description, date, transaction_id, user_id),
        )

        
        if type_ == "expense":
            month = date[:7]
            exceeded, total, lim = check_limit_exceeded(conn, user_id, month, category)
            if exceeded and lim is not None:
                flash(
                    f"⚠️ Przekroczono limit dla kategorii '{category}' w {month}: "
                    f"{total:.2f} zł / {lim:.2f} zł.",
                    "warning",
                )
        conn.commit()
        conn.close()
        flash("Zapisano zmiany.", "success")
        return redirect(url_for("web.index"))

    conn.close()
    return render_template("edit.html", title="Edytuj transakcję", transaction=transaction)

@bp.route("/delete/<int:transaction_id>", methods=["POST"])
def delete(transaction_id: int):
    if not require_login():
        return redirect(url_for("web.login"))

    _require_csrf()

    user_id = int(session["user_id"])
    conn = get_db_connection()
    repo_delete_transaction(conn, user_id, transaction_id)
    conn.commit()
    conn.close()
    flash("Usunięto transakcję.", "info")
    return redirect(url_for("web.index"))

@bp.route("/export", methods=["POST"])
def export():
    if not require_login():
        return redirect(url_for("web.login"))

    _require_csrf()

    user_id = int(session["user_id"])
    selected_month = (request.form.get("month") or current_month()).strip()
    search = (request.form.get("search") or "").strip()
    category_filter = (request.form.get("category") or "").strip()

   
    if not re.fullmatch(r"\d{4}-\d{2}", selected_month):
        selected_month = current_month()

    conn = get_db_connection()
    ensure_recurring_generated(conn, user_id)

    rows = repo_list_transactions_for_report(
        conn,
        user_id,
        selected_month,
        search=search,
        category_filter=category_filter,
    )

    conn.close()

    
    output = io.StringIO(newline="")
    writer = csv.writer(output, delimiter=";", lineterminator="\r\n", quoting=csv.QUOTE_MINIMAL)
    writer.writerow(["Data", "Kategoria", "Opis", "Kwota", "Typ"])

    for r in rows:
        amount = float(r["amount"])
        amount_str = f"{amount:.2f}".replace(".", ",")
        type_str = "przychód" if r["type"] == "income" else "wydatek"
        writer.writerow([
            r["date"],
            (r["category"] or "").strip(),
            (r["description"] or "").strip(),
            amount_str,
            type_str,
        ])

    data = output.getvalue().encode("utf-8-sig")  # BOM for Excel
    return send_file(
        io.BytesIO(data),
        mimetype="text/csv; charset=utf-8",
        download_name=f"transakcje_{selected_month}.csv",
        as_attachment=True,
    )

@bp.route("/report")
def report():
    if not require_login():
        return redirect(url_for("web.login"))

    user_id = int(session["user_id"])
    selected_month = (request.args.get("month") or current_month()).strip()
    search = (request.args.get("search") or "").strip()
    category_filter = (request.args.get("category") or "").strip()


    if not re.fullmatch(r"\d{4}-\d{2}", selected_month):
        selected_month = current_month()

    conn = get_db_connection()
    ensure_recurring_generated(conn, user_id)

    rows = repo_list_transactions_for_report(
        conn, user_id, selected_month, search=search, category_filter=category_filter
    )

    income_sum = repo_report_sum_month_by_type(conn, user_id, selected_month, "income")
    expense_sum = repo_report_sum_month_by_type(conn, user_id, selected_month, "expense")

    saldo_raw = float(income_sum) - float(expense_sum)
    frozen_total = compute_frozen_total(conn, user_id)
    saldo = float(saldo_raw) - float(frozen_total)

    income_categories, expense_categories = category_breakdown(rows)

    limit_warnings = get_limit_warnings(conn, user_id, selected_month)

    conn.close()

    return render_template(
        "report.html",
        title="Raport",
        selected_month=selected_month,
        search=search,
        category_filter=category_filter,
        transactions=rows,
        income_sum=float(income_sum),
        expense_sum=float(expense_sum),
        saldo=float(saldo),
        saldo_raw=float(saldo_raw),
        frozen_total=float(frozen_total),
        income_categories=income_categories,
        expense_categories=expense_categories,
        limit_warnings=limit_warnings,
    )

@bp.route("/limits", methods=["GET", "POST"])
def limits():
    if not require_login():
        return redirect(url_for("web.login"))

    user_id = int(session["user_id"])
    selected_month = (request.args.get("month") or current_month()).strip()

    if request.method == "POST":
        _require_csrf()
        month = (request.form.get("month") or "").strip()
        category = (request.form.get("category") or "").strip()
        limit_amount = parse_amount(request.form.get("limit_amount", ""))

        if not month or not re.fullmatch(r"\d{4}-\d{2}", month):
            flash("Nieprawidłowy miesiąc.", "danger")
            return redirect(url_for("web.limits"))
        if not category:
            flash("Kategoria jest wymagana.", "danger")
            return redirect(url_for("web.limits"))
        if limit_amount is None:
            flash("Nieprawidłowy limit.", "danger")
            return redirect(url_for("web.limits"))

        conn = get_db_connection()
        repo_upsert_limit(conn, user_id, month, category, limit_amount)
        conn.commit()
        conn.close()

        flash("Zapisano limit.", "success")
        return redirect(url_for("web.limits"))

    conn = get_db_connection()
    limits_rows = repo_list_limits(conn, user_id)
    conn.close()

    return render_template("limits.html", title="Limity", limits=limits_rows, selected_month=selected_month)

@bp.route("/limits/delete/<int:limit_id>", methods=["POST"])
def delete_limit(limit_id: int):
    if not require_login():
        return redirect(url_for("web.login"))

    _require_csrf()

    user_id = int(session["user_id"])
    conn = get_db_connection()
    repo_delete_limit(conn, user_id, limit_id)
    conn.commit()
    conn.close()
    flash("Usunięto limit.", "info")
    return redirect(url_for("web.limits"))



@bp.route("/recurring", methods=["GET", "POST"])
def recurring():
    if not require_login():
        return redirect(url_for("web.login"))

    user_id = int(session["user_id"])

    if request.method == "POST":
        _require_csrf()

        amount = parse_amount(request.form.get("amount", ""))
        type_ = (request.form.get("type") or "").strip()
        category = (request.form.get("category") or "").strip()
        description = (request.form.get("description") or "").strip()
        start_date = parse_date(request.form.get("start_date", ""))
        frequency = (request.form.get("frequency") or "").strip()
        end_date_raw = (request.form.get("end_date") or "").strip()
        end_date = None
        if end_date_raw:
            end_date = parse_date(end_date_raw)

        if amount is None:
            flash("Nieprawidłowa kwota.", "danger")
            return redirect(url_for("web.recurring"))
        if type_ not in ("income", "expense"):
            flash("Nieprawidłowy typ.", "danger")
            return redirect(url_for("web.recurring"))
        if not category:
            flash("Kategoria jest wymagana.", "danger")
            return redirect(url_for("web.recurring"))
        if start_date is None:
            flash("Nieprawidłowa data startu.", "danger")
            return redirect(url_for("web.recurring"))
        if frequency not in ALLOWED_FREQUENCIES:
            flash("Nieprawidłowa częstotliwość.", "danger")
            return redirect(url_for("web.recurring"))
        if end_date_raw and end_date is None:
            flash("Nieprawidłowa data końca.", "danger")
            return redirect(url_for("web.recurring"))

    
        if end_date:
            sd = recurring_parse_iso_date(start_date)
            ed = recurring_parse_iso_date(end_date)
            if sd and ed and ed < sd:
                flash("Data końca nie może być wcześniejsza niż data startu.", "danger")
                return redirect(url_for("web.recurring"))

        conn = get_db_connection()
        repo_create_recurring_rule(conn, user_id, amount, type_, category, description, start_date, frequency, end_date)
        conn.commit()

       
        ensure_recurring_generated(conn, user_id)
        conn.commit()
        conn.close()

        flash("Dodano transakcję cykliczną.", "success")
        return redirect(url_for("web.recurring"))

    conn = get_db_connection()
    
    ensure_recurring_generated(conn, user_id)
    conn.commit()

    rows = repo_list_recurring_rules(conn, user_id)
    conn.close()

    
    recurring_items = []
    for r in rows:
        d = dict(r)
        d["next_occurrence"] = get_next_occurrence(r)
        recurring_items.append(d)

    return render_template(
        "recurring.html",
        title="Cykliczne",
        today=datetime.today().strftime("%Y-%m-%d"),
        recurring_items=recurring_items,
    )

@bp.route("/recurring/toggle/<int:recurring_id>", methods=["POST"])
def recurring_toggle(recurring_id: int):
    if not require_login():
        return redirect(url_for("web.login"))

    _require_csrf()

    user_id = int(session["user_id"])
    conn = get_db_connection()
    row = repo_get_recurring_active_flag(conn, user_id, recurring_id)

    if not row:
        conn.close()
        flash("Nie znaleziono wpisu cyklicznego.", "warning")
        return redirect(url_for("web.recurring"))

    new_val = 0 if int(row["is_active"]) == 1 else 1
    repo_set_recurring_active_flag(conn, user_id, recurring_id, new_val)
    conn.commit()

   
    if new_val == 1:
        ensure_recurring_generated(conn, user_id)
        conn.commit()

    conn.close()
    flash("Zmieniono status wpisu cyklicznego.", "info")
    return redirect(url_for("web.recurring"))

@bp.route("/recurring/delete/<int:recurring_id>", methods=["POST"])
def recurring_delete(recurring_id: int):
    if not require_login():
        return redirect(url_for("web.login"))

    _require_csrf()

    user_id = int(session["user_id"])
    conn = get_db_connection()

   
    repo_delete_generated_transactions(conn, user_id, recurring_id)
    repo_delete_recurring_rule(conn, user_id, recurring_id)
    conn.commit()
    conn.close()

    flash("Usunięto wpis cykliczny (oraz wygenerowane transakcje).", "info")
    return redirect(url_for("web.recurring"))

@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        _require_csrf()
        username = (request.form.get("username") or "").strip()
        password = (request.form.get("password") or "").encode("utf-8")

        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        conn.close()

        if user and bcrypt.checkpw(password, user["password"]):
            session["user_id"] = int(user["id"])
            session["username"] = user["username"]
            flash("Zalogowano.", "success")
            return redirect(url_for("web.index"))

        flash("Nieprawidłowy login lub hasło.", "danger")

    return render_template("login.html", title="Logowanie")

@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        _require_csrf()
        username = (request.form.get("username") or "").strip()
        password_raw = (request.form.get("password") or "")

        if not USERNAME_RE.fullmatch(username):
            flash("Nieprawidłowa nazwa użytkownika (3–32 znaki, bez spacji).", "danger")
            return redirect(url_for("web.register"))
        if len(password_raw) < 6:
            flash("Hasło musi mieć co najmniej 6 znaków.", "danger")
            return redirect(url_for("web.register"))

        password = password_raw.encode("utf-8")
        hashed = bcrypt.hashpw(password, bcrypt.gensalt())

        conn = get_db_connection()
        try:
            conn.execute(
                "INSERT INTO users (username, password) VALUES (?, ?)",
                (username, hashed),
            )
            conn.commit()
            conn.close()
            flash("Konto utworzone. Zaloguj się.", "success")
            return redirect(url_for("web.login"))
        except Exception:
            conn.close()
            flash("Nazwa użytkownika jest już zajęta.", "warning")
            return redirect(url_for("web.register"))

    return render_template("register.html", title="Rejestracja")




def _goal_pct(current: float, target: float) -> int:
    """Return completion percent (0-100)."""
    if target <= 0:
        return 0
    pct = int(round((current / target) * 100))
    if pct < 0:
        return 0
    if pct > 100:
        return 100
    return pct


@bp.route("/goals", methods=["GET", "POST"])
def goals():
    if not require_login():
        return redirect(url_for("web.login"))

    user_id = int(session["user_id"])
    conn = get_db_connection()

    if request.method == "POST":
        _require_csrf()
        name = (request.form.get("name") or "").strip()
        target_amount_raw = (request.form.get("target_amount") or "").strip().replace(",", ".")
        target_date = (request.form.get("target_date") or "").strip() or None
        notes = (request.form.get("notes") or "").strip() or None

        if not name:
            conn.close()
            flash("Podaj nazwę celu.", "warning")
            return redirect(url_for("web.goals"))

        try:
            target_amount = float(target_amount_raw)
        except ValueError:
            conn.close()
            flash("Nieprawidłowa kwota celu.", "warning")
            return redirect(url_for("web.goals"))

        if target_amount < 0:
            conn.close()
            flash("Kwota celu nie może być ujemna.", "warning")
            return redirect(url_for("web.goals"))

        start_date = date.today().isoformat()

        repo_create_goal(conn, user_id, name, target_amount, start_date, target_date, notes)
        conn.commit()
        conn.close()
        flash("Dodano cel oszczędnościowy.", "success")
        return redirect(url_for("web.goals"))

 
    goals_rows = repo_list_goals(conn, user_id)

    goals_view = []
    for g in goals_rows:
        gid = int(g["id"])
        cur = float(g["current_amount"] or 0)
        tar = float(g["target_amount"] or 0)
        pct = _goal_pct(cur, tar)
        entries = repo_list_goal_entries(conn, user_id, gid, limit=5)

        goals_view.append({
            "id": gid,
            "name": g["name"],
            "target_amount": tar,
            "current_amount": cur,
            "pct": pct,
            "start_date": g["start_date"],
            "target_date": g["target_date"],
            "notes": g["notes"],
            "is_active": int(g["is_active"]),
            "entries": entries,
        })

    conn.close()
    return render_template(
        "goals.html",
        title="Cele oszczędnościowe",
        goals=goals_view,
        today=date.today().isoformat(),
    )


@bp.route("/goals/<int:goal_id>/entry", methods=["POST"])
def goal_entry(goal_id: int):
    if not require_login():
        return redirect(url_for("web.login"))

    _require_csrf()
    user_id = int(session["user_id"])

    kind = (request.form.get("kind") or "deposit").strip().lower()
    amount_raw = (request.form.get("amount") or "").strip().replace(",", ".")
    entry_date = (request.form.get("entry_date") or "").strip() or date.today().isoformat()
    note = (request.form.get("note") or "").strip() or None

    try:
        amount = float(amount_raw)
    except ValueError:
        flash("Nieprawidłowa kwota wpłaty/wypłaty.", "warning")
        return redirect(url_for("web.goals"))

    if amount <= 0:
        flash("Kwota musi być większa od zera.", "warning")
        return redirect(url_for("web.goals"))

    signed = amount if kind == "deposit" else -amount

    conn = get_db_connection()
    goal = repo_get_goal_for_entry(conn, user_id, goal_id)

    if not goal:
        conn.close()
        flash("Nie znaleziono celu.", "warning")
        return redirect(url_for("web.goals"))

    if int(goal["is_active"]) != 1:
        conn.close()
        flash("Cel jest nieaktywny — włącz go, aby dodać wpłatę.", "warning")
        return redirect(url_for("web.goals"))

    current = float(goal["current_amount"] or 0)
    new_amount = current + signed
    if new_amount < 0:
        new_amount = 0.0  

    repo_add_goal_entry_and_update_current(conn, user_id, goal_id, signed, entry_date, note, new_amount)
    conn.commit()
    conn.close()

    flash("Zapisano aktualizację celu.", "success")
    return redirect(url_for("web.goals"))


@bp.route("/goals/toggle/<int:goal_id>", methods=["POST"])
def goals_toggle(goal_id: int):
    if not require_login():
        return redirect(url_for("web.login"))

    _require_csrf()
    user_id = int(session["user_id"])
    conn = get_db_connection()
    row = repo_get_goal_active_flag(conn, user_id, goal_id)

    if not row:
        conn.close()
        flash("Nie znaleziono celu.", "warning")
        return redirect(url_for("web.goals"))

    new_val = 0 if int(row["is_active"]) == 1 else 1
    repo_set_goal_active_flag(conn, user_id, goal_id, new_val)
    conn.commit()
    conn.close()
    flash("Zmieniono status celu.", "info")
    return redirect(url_for("web.goals"))


@bp.route("/goals/delete/<int:goal_id>", methods=["POST"])
def goals_delete(goal_id: int):
    if not require_login():
        return redirect(url_for("web.login"))

    _require_csrf()
    user_id = int(session["user_id"])
    conn = get_db_connection()
    repo_delete_goal(conn, user_id, goal_id)
    conn.commit()
    conn.close()
    flash("Usunięto cel.", "info")
    return redirect(url_for("web.goals"))

@bp.route("/logout")
def logout():
    session.clear()
    flash("Wylogowano.", "info")
    return redirect(url_for("web.login"))

if __name__ == "__main__":
    
    app.run(debug=True)