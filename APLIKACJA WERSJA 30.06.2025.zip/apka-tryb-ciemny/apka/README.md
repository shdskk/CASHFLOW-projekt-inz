# apka-na-inzynierke
cos se klikamy
