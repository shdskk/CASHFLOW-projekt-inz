@echo off
REM ────────── aktywuj / utwórz venv ──────────
if exist venv\Scripts\activate (
    call venv\Scripts\activate
) else (
    echo [INFO] Tworzę wirtualne środowisko venv...
    python -m venv venv
    call venv\Scripts\activate
    echo [INFO] Instaluję zależności...
    pip install -r requirements.txt
)

REM ────────── zmienne środowiskowe ──────────
set FLASK_APP=app.py
set FLASK_ENV=development

REM ────────── uruchom serwer w NOWYM oknie ──────────
start "BudgetApp-Server" cmd /k python app.py

REM ────────── poczekaj 2 sekundy i otwórz przeglądarkę ──────────
timeout /t 2 /nobreak > nul
start "" http://127.0.0.1:5000
