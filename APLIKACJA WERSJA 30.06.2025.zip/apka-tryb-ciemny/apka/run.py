import os, subprocess, sys, venv, pathlib, platform, threading, time, webbrowser

ROOT = pathlib.Path(__file__).parent
VENV = ROOT / "venv"

# 1) venv
if not VENV.exists():
    print("[INFO] Tworzę wirtualne środowisko venv…")
    venv.create(VENV, with_pip=True)

py = VENV / ("Scripts" if platform.system()=="Windows" else "bin") / "python"

# 2) requirements
req_lock = VENV / ".requirements_installed"
if not req_lock.exists():
    subprocess.check_call([str(py), "-m", "pip", "install", "-r", "requirements.txt"])
    req_lock.touch()

# 3) otwórz przeglądarkę po chwili
def open_browser():
    time.sleep(2)
    webbrowser.open("http://127.0.0.1:5000")
threading.Thread(target=open_browser, daemon=True).start()

# 4) uruchom serwer
env = os.environ.copy()
env.setdefault("FLASK_APP", "app.py")
env.setdefault("FLASK_ENV", "development")
subprocess.call([str(py), "app.py"], env=env)
