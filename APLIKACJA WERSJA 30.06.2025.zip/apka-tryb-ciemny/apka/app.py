from flask import (
    Flask, render_template, request, redirect,
    session, flash, url_for, send_file
)
import sqlite3, bcrypt, csv, io, requests, re
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = "tajny_klucz_sesji"

DB_PATH = "budget.db"
SUPPORTED_CUR = ["PLN", "EUR", "USD"]
TAG_RE = re.compile(r'#(\w+)', re.UNICODE)

# ────────────────────────────────── DB / migracje ──────────────────────────────────
def db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c

def ensure_schema():
    """Tworzy brakujące tabele / kolumny przy starcie."""
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY,
        username TEXT UNIQUE,
        password TEXT
    );

    CREATE TABLE IF NOT EXISTS transactions(
        id INTEGER PRIMARY KEY,
        user_id INTEGER,
        amount REAL,
        currency TEXT DEFAULT 'PLN',
        amount_pln REAL,
        type TEXT,
        category TEXT,
        description TEXT,
        date TEXT,
        is_recurring INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS budgets(
        id INTEGER PRIMARY KEY,
        user_id INTEGER,
        category TEXT,
        month TEXT,
        limit_amt REAL,
        UNIQUE(user_id, category, month)
    );

    CREATE TABLE IF NOT EXISTS fx_cache(
        code TEXT,
        date TEXT,
        rate REAL,
        PRIMARY KEY(code, date)
    );

    CREATE TABLE IF NOT EXISTS goals(
        id INTEGER PRIMARY KEY,
        user_id INTEGER,
        name   TEXT,
        target REAL,
        saved  REAL DEFAULT 0,
        mode   TEXT DEFAULT 'manual',   -- manual | category | tag
        link   TEXT,
        deadline TEXT,
        created  TEXT
    );

    /* TAGI */
    CREATE TABLE IF NOT EXISTS tags(
        id INTEGER PRIMARY KEY,
        name TEXT UNIQUE
    );
    CREATE TABLE IF NOT EXISTS tx_tags(
        tx_id  INTEGER,
        tag_id INTEGER,
        PRIMARY KEY(tx_id, tag_id),
        FOREIGN KEY(tx_id)  REFERENCES transactions(id) ON DELETE CASCADE,
        FOREIGN KEY(tag_id) REFERENCES tags(id)         ON DELETE CASCADE
    );
    """)
    # kolumny walutowe w starych bazach
    cols = [c["name"] for c in conn.execute("PRAGMA table_info(transactions)")]
    if "currency"   not in cols:
        conn.execute("ALTER TABLE transactions ADD COLUMN currency TEXT DEFAULT 'PLN'")
    if "amount_pln" not in cols:
        conn.execute("ALTER TABLE transactions ADD COLUMN amount_pln REAL")
    conn.commit(); conn.close()

ensure_schema()

# ─────────────────────────────── FX (NBP) ───────────────────────────────
def fx_rate(code: str, date: str) -> float:
    code = code.upper()
    if code == "PLN":
        return 1.0
    conn = db()
    row = conn.execute("SELECT rate FROM fx_cache WHERE code=? AND date=?", (code, date)).fetchone()
    if row:
        conn.close()
        return row["rate"]

    url = f"https://api.nbp.pl/api/exchangerates/rates/A/{code}/{date}?format=json"
    r = requests.get(url, timeout=5)
    if r.status_code == 404:  # brak notowania – bierz dzień wcześniejszy
        prev = (datetime.strptime(date, "%Y-%m-%d") - timedelta(days=1)).strftime("%Y-%m-%d")
        return fx_rate(code, prev)
    r.raise_for_status()
    rate = r.json()["rates"][0]["mid"]

    conn.execute("INSERT INTO fx_cache VALUES (?,?,?)", (code, date, rate))
    conn.commit(); conn.close()
    return rate

# ─────────────────────────────── TAG helpers ───────────────────────────────
def extract_tags(text: str) -> set[str]:
    return {m.lower() for m in TAG_RE.findall(text or "")}

def save_tags(tx_id: int, tag_names: set[str]):
    conn = db()
    conn.execute("DELETE FROM tx_tags WHERE tx_id=?", (tx_id,))

    for name in tag_names:
        # 1) spróbuj wstawić nowy tag
        conn.execute("INSERT OR IGNORE INTO tags(name) VALUES (?)", (name,))
        # 2) pobierz id (czy nowy, czy istniejący)
        tag_id = conn.execute("SELECT id FROM tags WHERE name=?", (name,)).fetchone()["id"]
        # 3) powiąż z transakcją
        conn.execute("INSERT OR IGNORE INTO tx_tags VALUES (?,?)", (tx_id, tag_id))

    conn.commit()
    conn.close()


def get_all_tags(uid: int):
    return db().execute("""
        SELECT DISTINCT g.name
        FROM tags g
        JOIN tx_tags x ON x.tag_id = g.id
        JOIN transactions t ON t.id = x.tx_id
        WHERE t.user_id = ?
        ORDER BY g.name
    """, (uid,)).fetchall()

# ─────────────────────────────── Recurring copy ───────────────────────────────
def duplicate_recurring(uid: int, month_tag: str):
    conn = db()
    if not conn.execute("SELECT 1 FROM transactions WHERE user_id=? AND date LIKE ? LIMIT 1",
                        (uid, month_tag + "%")).fetchone():
        cur = datetime.strptime(month_tag + "-01", "%Y-%m-%d")
        prev = cur.replace(year=cur.year - 1, month=12) if cur.month == 1 else cur.replace(month=cur.month - 1)
        prev_tag = prev.strftime("%Y-%m")
        for r in conn.execute("""
              SELECT amount,currency,amount_pln,type,category,description
              FROM transactions
              WHERE user_id=? AND is_recurring=1 AND date LIKE ?""",
                              (uid, prev_tag + "%")):
            conn.execute("""
              INSERT INTO transactions(amount,currency,amount_pln,type,category,description,
                                       date,user_id,is_recurring)
              VALUES(?,?,?,?,?,?, ?,1)""",
                         (*r[:-1], month_tag + "-01", uid))
        conn.commit()
    conn.close()

# ─────────────────────────────── Goals helpers ───────────────────────────────
def trigger_goals_auto(uid: int, amt_pln: float, category: str, description: str):
    conn = db()
    conn.execute("""
        UPDATE goals SET saved = saved + ?
        WHERE user_id=? AND mode='category' AND link=?""", (amt_pln, uid, category))

    tags = extract_tags(description)
    if tags:
        placeholders = ",".join("?" * len(tags))
        conn.execute(f"""
            UPDATE goals SET saved = saved + ?
            WHERE user_id=? AND mode='tag' AND link IN ({placeholders})""",
                     (amt_pln, uid, *tags))
    conn.commit(); conn.close()

# ─────────────────────────────── INDEX (dashboard) ───────────────────────────────
@app.route("/")
def index():
    if "user_id" not in session:
        return redirect("/login")

    uid = session["user_id"]
    today = datetime.today()
    start = request.args.get("start", (today - timedelta(days=90)).strftime("%Y-%m-%d"))
    end   = request.args.get("end",   today.strftime("%Y-%m-%d"))
    if end < start:
        start, end = end, start

    duplicate_recurring(uid, end[:7])

    # filtry
    fx_filter = request.args.get("fx", "").upper().strip()
    search    = request.args.get("search", "").strip()
    category  = request.args.get("category", "").strip()
    tag_filter = request.args.get("tag", "").strip().lower()

    # bazowe parametry
    p = [uid, start, end]

    if tag_filter:
        q = """
          SELECT t.*
          FROM transactions t
          JOIN tx_tags x ON x.tx_id = t.id
          JOIN tags g    ON g.id   = x.tag_id
          WHERE t.user_id=? AND t.date BETWEEN ? AND ? AND g.name=?
        """
        p.append(tag_filter)
    else:
        q = "SELECT * FROM transactions WHERE user_id=? AND date BETWEEN ? AND ?"

    if search:
        q += " AND description LIKE ?"; p.append(f"%{search}%")
    if category:
        q += " AND category LIKE ?";   p.append(f"%{category}%")
    if fx_filter:
        q += " AND currency=?";        p.append(fx_filter)
    q += " ORDER BY date DESC"

    conn = db()
    tx = conn.execute(q, tuple(p)).fetchall()

    income = conn.execute("""
        SELECT COALESCE(SUM(amount_pln),0)
        FROM transactions WHERE user_id=? AND type='income' AND date BETWEEN ? AND ?""",
        (uid, start, end)).fetchone()[0]
    expense = conn.execute("""
        SELECT COALESCE(SUM(amount_pln),0)
        FROM transactions WHERE user_id=? AND type='expense' AND date BETWEEN ? AND ?""",
        (uid, start, end)).fetchone()[0]

    # limity
    month_tag = end[:7]
    limits = conn.execute("SELECT category, limit_amt FROM budgets WHERE user_id=? AND month=?",
                          (uid, month_tag)).fetchall()
    spent = dict(conn.execute("""
        SELECT category, SUM(amount_pln) s
        FROM transactions
        WHERE user_id=? AND type='expense' AND date LIKE ?
        GROUP BY category
    """, (uid, month_tag + "%")))
    budgets = [dict(category=l["category"],
                    limit=l["limit_amt"],
                    spent=spent.get(l["category"], 0),
                    ratio=spent.get(l["category"], 0) / l["limit_amt"] if l["limit_amt"] else 0)
               for l in limits]

    goals_top = conn.execute("""
        SELECT *, (target-saved) rest
        FROM goals WHERE user_id=?
        ORDER BY rest LIMIT 3""", (uid,)).fetchall()

    # wykres miesięczny
    chart = {}
    for r in conn.execute("""
        SELECT substr(date,1,7) m, type, SUM(amount_pln) s
        FROM transactions
        WHERE user_id=? AND date BETWEEN ? AND ?
        GROUP BY m, type
    """, (uid, start, end)):
        m = r["m"]; chart.setdefault(m, {"inc": 0, "exp": 0})
        if r["type"] == "income":
            chart[m]["inc"] = r["s"]
        else:
            chart[m]["exp"] = r["s"]

    labels = sorted(chart.keys())
    conn.close()

    return render_template("index.html",
        transactions=tx,
        income_sum=income,
        expense_sum=expense,
        saldo=income - expense,
        start_date=start,
        end_date=end,
        fx_filter=fx_filter,
        tag_filter=tag_filter,
        budgets=budgets,
        goals_top=goals_top,
        chart_labels=labels,
        chart_income=[chart[m]["inc"] for m in labels],
        chart_expense=[chart[m]["exp"] for m in labels],
        all_tags=get_all_tags(uid)
    )

# ─────────────────────────────── TAG-statystyki ───────────────────────────────
@app.route("/tags/stats")
def tags_stats():
    if "user_id" not in session:
        return redirect("/login")

    uid = session["user_id"]
    rows = db().execute("""
        SELECT g.name, SUM(t.amount_pln) spent
        FROM tags g
        JOIN tx_tags x ON x.tag_id = g.id
        JOIN transactions t ON t.id = x.tx_id
        WHERE t.user_id=? AND t.type='expense'
        GROUP BY g.name
        ORDER BY spent DESC
    """, (uid,)).fetchall()
    return render_template("tags_stats.html", rows=rows)

# ─────────────────────────────── GOALS CRUD + wpłata ───────────────────────────────
@app.route("/goals")
def goals():
    if "user_id" not in session:
        return redirect("/login")
    rows = db().execute("""
        SELECT *, (target-saved) rest
        FROM goals WHERE user_id=?
        ORDER BY created DESC
    """, (session["user_id"],)).fetchall()
    return render_template("goals.html", rows=rows)

@app.route("/goals/add", methods=["GET", "POST"])
def goals_add():
    if "user_id" not in session:
        return redirect("/login")

    if request.method == "POST":
        name = request.form["name"]
        target = float(request.form["target"])
        mode = request.form["mode"]
        link = request.form.get("link") or None
        deadline = request.form.get("deadline") or None

        conn = db()
        conn.execute("""
            INSERT INTO goals(user_id,name,target,mode,link,deadline,created)
            VALUES(?,?,?,?,?,?,DATE('now'))""",
                     (session["user_id"], name, target, mode, link, deadline))
        conn.commit(); conn.close()
        return redirect(url_for("index"))

    return render_template("goal_form.html",
                           action="add",
                           cur_date=datetime.today().strftime("%Y-%m-%d"))

@app.route("/goals/edit/<int:gid>", methods=["GET", "POST"])
def goals_edit(gid):
    if "user_id" not in session:
        return redirect("/login")

    conn = db()
    row = conn.execute("SELECT * FROM goals WHERE id=? AND user_id=?",
                       (gid, session["user_id"])).fetchone()
    if not row:
        conn.close(); flash("Cel nie istnieje."); return redirect("/goals")

    if request.method == "POST":
        target = float(request.form["target"])
        deadline = request.form.get("deadline") or None
        conn.execute("UPDATE goals SET target=?, deadline=? WHERE id=?",
                     (target, deadline, gid))
        conn.commit(); conn.close()
        return redirect(url_for("goals"))

    conn.close()
    return render_template("goal_form.html", action="edit", row=row)

@app.route("/goals/delete/<int:gid>")
def goals_delete(gid):
    if "user_id" not in session:
        return redirect("/login")
    conn = db(); conn.execute("DELETE FROM goals WHERE id=? AND user_id=?", (gid, session["user_id"]))
    conn.commit(); conn.close()
    return redirect("/goals")

@app.route("/goals/pay/<int:gid>", methods=["POST"])
def goals_pay(gid):
    if "user_id" not in session:
        return redirect("/login")
    try:
        amt = float(request.form["amount"])
        assert amt > 0
    except (ValueError, AssertionError):
        flash("Kwota musi być dodatnia.")
        return redirect("/goals")

    conn = db()
    conn.execute("UPDATE goals SET saved = saved + ? WHERE id=? AND user_id=?",
                 (amt, gid, session["user_id"]))
    conn.commit(); conn.close()
    flash("Wpłata zapisana.")
    return redirect("/goals")

# ─────────────────────────────── BUDGETS (limity) ───────────────────────────────
@app.route("/budgets")
def budgets():
    if "user_id" not in session:
        return redirect("/login")
    month = request.args.get("month", datetime.today().strftime("%Y-%m"))
    rows = db().execute("""
        SELECT * FROM budgets WHERE user_id=? AND month=? ORDER BY category
    """, (session["user_id"], month)).fetchall()
    return render_template("limits.html", rows=rows, month=month)

@app.route("/budgets/add", methods=["GET", "POST"])
def budgets_add():
    if "user_id" not in session:
        return redirect("/login")
    if request.method == "POST":
        cat = request.form["category"]
        month = request.form["month"]
        limit = float(request.form["limit_amount"])
        conn = db()
        try:
            conn.execute("INSERT INTO budgets(user_id,category,month,limit_amt) VALUES(?,?,?,?)",
                         (session["user_id"], cat, month, limit))
            conn.commit()
        except sqlite3.IntegrityError:
            flash("Limit dla tej kategorii w tym miesiącu już istnieje.")
        finally:
            conn.close()
        return redirect(url_for("budgets", month=month))

    return render_template("budget_form.html",
                           action="add",
                           month=datetime.today().strftime("%Y-%m"))

@app.route("/budgets/edit/<int:bid>", methods=["GET", "POST"])
def budgets_edit(bid):
    if "user_id" not in session:
        return redirect("/login")
    conn = db()
    row = conn.execute("SELECT * FROM budgets WHERE id=? AND user_id=?",
                       (bid, session["user_id"])).fetchone()
    if not row:
        conn.close(); flash("Limit nie istnieje."); return redirect("/budgets")

    if request.method == "POST":
        new_lim = float(request.form["limit_amount"])
        conn.execute("UPDATE budgets SET limit_amt=? WHERE id=?", (new_lim, bid))
        conn.commit(); conn.close()
        return redirect(url_for("budgets", month=row["month"]))

    conn.close()
    return render_template("budget_form.html", action="edit", row=row)

@app.route("/budgets/delete/<int:bid>")
def budgets_delete(bid):
    if "user_id" not in session:
        return redirect("/login")
    conn = db()
    conn.execute("DELETE FROM budgets WHERE id=? AND user_id=?", (bid, session["user_id"]))
    conn.commit(); conn.close()
    return redirect(request.referrer or url_for("budgets"))

# ─────────────────────────────── TRANSAKCJE CRUD ───────────────────────────────
@app.route("/add", methods=["GET", "POST"])
def add():
    if "user_id" not in session:
        return redirect("/login")

    if request.method == "POST":
        amt = float(request.form["amount"])
        cur = request.form["currency"].upper()
        date = request.form["date"]
        amt_pln = round(amt * fx_rate(cur, date), 2)
        desc = request.form.get("description", "")
        is_rec = 1 if request.form.get("is_recurring") else 0

        conn = db()
        c = conn.cursor()
        c.execute("""
            INSERT INTO transactions(user_id,amount,currency,amount_pln,type,category,
                                     description,date,is_recurring)
            VALUES(?,?,?,?,?,?, ?,?,?)""",
                  (session["user_id"], amt, cur, amt_pln, request.form["type"],
                   request.form["category"], desc, date, is_rec))
        tx_id = c.lastrowid
        conn.commit(); conn.close()

        save_tags(tx_id, extract_tags(desc))
        if request.form["type"] == "income":
            trigger_goals_auto(session["user_id"], amt_pln,
                               request.form["category"], desc)
        return redirect("/")

    return render_template("add.html",
                           now=datetime.today(),
                           cur_list=SUPPORTED_CUR,
                           all_tags=get_all_tags(session["user_id"]))

@app.route("/edit/<int:tid>", methods=["GET", "POST"])
def edit(tid):
    if "user_id" not in session:
        return redirect("/login")
    conn = db()
    row = conn.execute("SELECT * FROM transactions WHERE id=? AND user_id=?",
                       (tid, session["user_id"])).fetchone()
    if not row:
        conn.close(); flash("Brak transakcji."); return redirect("/")

    if request.method == "POST":
        amt = float(request.form["amount"])
        cur = request.form["currency"].upper()
        date = request.form["date"]
        amt_pln = round(amt * fx_rate(cur, date), 2)
        desc = request.form.get("description", "")
        is_rec = 1 if request.form.get("is_recurring") else 0

        conn.execute("""
            UPDATE transactions
            SET amount=?,currency=?,amount_pln=?,type=?,category=?,description=?,
                date=?,is_recurring=?
            WHERE id=? AND user_id=?""",
                     (amt, cur, amt_pln, request.form["type"], request.form["category"],
                      desc, date, is_rec, tid, session["user_id"]))
        conn.commit(); conn.close()
        save_tags(tid, extract_tags(desc))
        return redirect("/")

    conn.close()
    return render_template("edit.html",
                           transaction=row,
                           cur_list=SUPPORTED_CUR,
                           all_tags=get_all_tags(session["user_id"]))

@app.route("/delete/<int:tid>")
def delete(tid):
    if "user_id" not in session:
        return redirect("/login")
    conn = db()
    conn.execute("DELETE FROM transactions WHERE id=? AND user_id=?", (tid, session["user_id"]))
    conn.commit(); conn.close()
    return redirect("/")

# ─────────────────────────────── Eksport CSV ───────────────────────────────
@app.route("/export", methods=["POST"])
def export():
    if "user_id" not in session:
        return redirect("/login")
    uid = session["user_id"]
    start = request.form["start"]
    end = request.form["end"]

    rows = db().execute("""
        SELECT date,category,description,amount,currency,amount_pln,type
        FROM transactions
        WHERE user_id=? AND date BETWEEN ? AND ?
        ORDER BY date
    """, (uid, start, end)).fetchall()

    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["Data", "Kategoria", "Opis", "Kwota", "Waluta", "Kwota PLN", "Typ"])
    for r in rows:
        w.writerow(r)
    out.seek(0)

    return send_file(io.BytesIO(out.getvalue().encode()),
                     mimetype="text/csv",
                     as_attachment=True,
                     download_name="transakcje.csv")

# ─────────────────────────────── AUTH ───────────────────────────────
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        uname = request.form["username"]
        pwd = request.form["password"].encode()

        conn = db()
        u = conn.execute("SELECT * FROM users WHERE username=?", (uname,)).fetchone()
        conn.close()

        if u and bcrypt.checkpw(pwd, u["password"]):
            session["user_id"] = u["id"]
            session["username"] = u["username"]
            return redirect("/")
        flash("Błędny login lub hasło.")
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        uname = request.form["username"]
        pwd_h = bcrypt.hashpw(request.form["password"].encode(), bcrypt.gensalt())
        conn = db()
        try:
            conn.execute("INSERT INTO users(username,password) VALUES(?,?)",
                         (uname, pwd_h))
            conn.commit(); return redirect("/login")
        except sqlite3.IntegrityError:
            flash("Nazwa użytkownika jest zajęta.")
        finally:
            conn.close()
    return render_template("register.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

# ─────────────────────────────── DEBUG MAPA ───────────────────────────────
if __name__ == "__main__":
    print("\nEndpointy:")
    for r in app.url_map.iter_rules():
        print(f"{r.endpoint:25} -> {r}")
    app.run(debug=True)
